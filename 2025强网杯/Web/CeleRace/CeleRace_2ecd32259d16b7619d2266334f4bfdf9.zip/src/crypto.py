from __future__ import annotations

import json
import socket
from hashlib import md5, sha1
from typing import Any

from Crypto.Cipher import AES

from .config import settings
import logging
_TASK_KEY = sha1(settings.secret_key.encode()).digest()[:16]
_TASK_NONCE = md5(socket.gethostname().encode()).digest()[:8]
logging.basicConfig(level=logging.INFO)

def encrypt_bytes(data: bytes) -> bytes:
    cipher = AES.new(_TASK_KEY, AES.MODE_CTR, nonce=_TASK_NONCE)
    return cipher.encrypt(data)


def decrypt_bytes(data: bytes) -> bytes:
    cipher = AES.new(_TASK_KEY, AES.MODE_CTR, nonce=_TASK_NONCE)
    return cipher.decrypt(data)


def dumps(payload: Any) -> bytes:
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return encrypt_bytes(raw)


def loads(ciphertext: bytes) -> Any:
    raw = decrypt_bytes(ciphertext)
    return json.loads(raw.decode("utf-8"))
