from __future__ import annotations

import hashlib
import os
from typing import Dict, Optional

from framework import session

from . import storage

USERS_FILE = "users.json"


class AuthError(Exception):
    pass


def _hash_password(password: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()


def _get_users() -> Dict[str, Dict[str, str]]:
    return storage.read_json(USERS_FILE, default={})


def _save_users(users: Dict[str, Dict[str, str]]) -> None:
    storage.write_json(USERS_FILE, users)


def register(username: str, password: str) -> None:
    username = username.strip().lower()
    if not username or not password:
        raise AuthError("username and password required")
    users = _get_users()
    if username in users:
        raise AuthError("user exists")
    salt = os.urandom(8).hex()
    users[username] = {"salt": salt, "password": _hash_password(password, salt), "role": "user"}
    _save_users(users)
    session["user"] = username
    session["role"] = "user"


def authenticate(username: str, password: str) -> None:
    username = username.strip().lower()
    users = _get_users()
    record = users.get(username)
    if not record:
        raise AuthError("invalid credentials")
    salt = record["salt"]
    if _hash_password(password, salt) != record["password"]:
        raise AuthError("invalid credentials")
    session["user"] = username
    session["role"] = record.get("role", "user")


def current_user() -> Optional[str]:
    return session.get("user")


def current_role() -> str:
    return session.get("role", "guest")


def logout() -> None:
    session.clear()
