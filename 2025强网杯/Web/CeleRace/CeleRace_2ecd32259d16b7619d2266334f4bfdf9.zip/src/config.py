from __future__ import annotations

import os
from dataclasses import dataclass


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default)


@dataclass(frozen=True)
class Settings:
    secret_key: str = _env("SESSION_SECRET", "devsecret")
    data_dir: str = _env("APP_DATA_DIR", "/tmp/miniws")
    celery_broker_url: str = _env("CELERY_BROKER_URL", "redis://localhost:6379/0")
    celery_backend_url: str = _env("CELERY_RESULT_BACKEND", "redis://localhost:6379/0")
    redis_host: str = _env("REDIS_HOST", "localhost")
    redis_port: int = int(_env("REDIS_PORT", "6379"))
    flag_path: str = _env("FLAG_PATH", "/flag.txt")


settings = Settings()
