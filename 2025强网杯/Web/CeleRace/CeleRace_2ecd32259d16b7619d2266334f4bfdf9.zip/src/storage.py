from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from .config import settings

DEFAULT_DATA_DIR = Path(settings.data_dir)
DEFAULT_DATA_DIR.mkdir(parents=True, exist_ok=True)


def _path(filename: str) -> Path:
    return DEFAULT_DATA_DIR / filename


def read_json(filename: str, default: Dict[str, Any] | None = None) -> Dict[str, Any]:
    path = _path(filename)
    if not path.exists():
        return default or {}
    try:
        with path.open("r", encoding="utf-8") as fh:
            return json.load(fh)
    except json.JSONDecodeError:
        return default or {}


def write_json(filename: str, data: Dict[str, Any]) -> None:
    path = _path(filename)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    with tmp_path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    tmp_path.replace(path)
