from __future__ import annotations

import os
import pickle
import socket
from typing import Any, Dict
from urllib.parse import urlparse

from celery import Celery
from kombu.serialization import register

from .config import settings
from .crypto import dumps as encrypt_dumps, loads as decrypt_loads

try:
    register(
        "miniws-aes",
        encrypt_dumps,
        decrypt_loads,
        content_type="application/x-miniws",
        content_encoding="binary",
    )
except ValueError:
    pass

celery_app = Celery(
    "miniws",
    broker=settings.celery_broker_url,
    backend=settings.celery_backend_url,
)

celery_app.conf.update(
    task_serializer="miniws-aes",
    task_default_serializer="miniws-aes",
    accept_content=["miniws-aes"],
    result_serializer="json",
    result_accept_content=["json"],
)


@celery_app.task(name="miniws.echo")
def echo_task(message: str) -> Dict[str, Any]:
    return {"echo": message}


@celery_app.task(name="miniws.fetch")
def fetch_task(url: str, *, host_header: str | None = None, body: str | None = None, verb: str = "GET") -> Dict[str, Any]:
    parsed = urlparse(url)
    host = parsed.hostname or settings.redis_host
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"

    request_host = host_header or parsed.netloc or f"{host}:{port}"
    request_body = body.encode() if body else b""

    payload = (
        f"{verb} {path} HTTP/1.1\r\n"
        f"Host: {request_host}\r\n"
        "User-Agent: MiniFetch/1.0\r\n"
        "Connection: close\r\n"
        "\r\n"
    ).encode() + request_body

    chunks: list[bytes] = []
    with socket.create_connection((host, port), timeout=5) as sock:
        sock.sendall(payload)
        while True:
            data = sock.recv(4096)
            if not data:
                break
            chunks.append(data)
    preview = b"".join(chunks)[:2048]
    return {"preview": preview.decode(errors="replace"), "bytes": len(preview)}
    
