from __future__ import annotations

import mimetypes
from pathlib import Path

from framework import MiniFlask, jsonify, request, session, save_session

from . import auth
from .tasks import celery_app

STATIC_DIR = (Path(__file__).resolve().parent.parent / "static").resolve()

app = MiniFlask(__name__)


def require_login(next_handler):
    def wrapper(**kwargs):
        if not session.get("user"):
            return jsonify({"error": "login required"}, status=403)
        return next_handler(**kwargs)

    return wrapper


def require_admin(next_handler):
    def wrapper(**kwargs):
        if session.get("role") != "admin":
            return jsonify({"error": "admin only"}, status=403)
        return next_handler(**kwargs)

    return wrapper


@app.before_request
def load_user() -> None:
    username = session.get("user")
    if username:
        request.user = username
        request.role = session.get("role", "user")
    else:
        request.user = "guest"
        request.role = "guest"


@app.after_request
def ensure_cookie(response):
    response.headers.setdefault("X-App", "MiniWSGI")
    return response

def _static_response(path: Path):
    from werkzeug.exceptions import NotFound

    if not path.exists() or not path.is_file():
        raise NotFound()
    mimetype, _ = mimetypes.guess_type(str(path))
    with path.open("rb") as fh:
        data = fh.read()
    return app.response_class(data, mimetype=mimetype or "application/octet-stream")


@app.get("/")
def frontend():
    return _static_response(STATIC_DIR / "index.html")


@app.get("/static/app.js")
def static_app_js():
    return _static_response(STATIC_DIR / "app.js")


@app.get("/static/style.css")
def static_style_css():
    return _static_response(STATIC_DIR / "style.css")


@app.get("/api/info")
def api_info():
    return jsonify({"message": "MiniWSGI Task Board", "user": request.user})


@app.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    try:
        auth.register(data.get("username", ""), data.get("password", ""))
        save_session()
    except auth.AuthError as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify({"message": "registered", "user": auth.current_user()})


@app.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    try:
        auth.authenticate(data.get("username", ""), data.get("password", ""))
        save_session()
    except auth.AuthError as exc:
        return jsonify({"error": str(exc)}), 401
    return jsonify({"message": "logged in", "user": auth.current_user()})


@app.post("/logout")
def logout():
    auth.logout()
    save_session()
    return jsonify({"message": "logged out"})


@app.get("/session")
def session_info():
    return jsonify({"user": session.get("user", "guest"), "role": session.get("role", "guest")})


def _queue(task_name: str, **kwargs):
    result = celery_app.send_task(task_name, kwargs=kwargs)
    return jsonify({"task_id": result.id, "task": task_name})


@app.post("/tasks/echo")
def queue_echo():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    return _queue("miniws.echo", message=message)


@app.post("/tasks/fetch", middlewares=[require_admin])
def queue_fetch_root():
    return queue_fetch("")


@app.post("/tasks/fetch/<path:target>", middlewares=[require_admin])
def queue_fetch(target: str):
    payload = request.get_json(silent=True) or {}
    url = payload.get("url") or target
    verb = payload.get("verb", "GET")
    if not url:
        return jsonify({"error": "url required"}, status=400)
    host_header = payload.get("host")
    body = payload.get("body")
    return _queue("miniws.fetch", url=url, host_header=host_header, body=body, verb=verb)



@app.get("/tasks/result")
def task_result():
    task_id = request.args.get("id")
    if not task_id:
        return jsonify({"error": "task id required"}, status=400)
    result = celery_app.AsyncResult(task_id)
    if not result.ready():
        return jsonify({"state": result.state})
    return jsonify({"state": result.state, "result": result.result})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
