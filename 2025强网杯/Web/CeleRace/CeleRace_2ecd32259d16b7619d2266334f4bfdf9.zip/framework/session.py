from __future__ import annotations

import json
import os
import secrets
from typing import Any, Dict, Optional

from werkzeug.wrappers import Request

class FileSession(dict):
    """Mutable mapping storing session data with dirty tracking."""

    def __init__(self, manager: "FileSessionManager", sid: str, nonce: str, data: Optional[Dict[str, Any]] = None, *, new: bool = False) -> None:
        super().__init__(data or {})
        self.manager = manager
        self.sid = sid
        self.nonce = nonce
        self.modified = new
        self.cookie_needs_update = new

    # -- dirty tracking -------------------------------------------------
    def _mark_modified(self) -> None:
        self.modified = True

    def __setitem__(self, key: str, value: Any) -> None:  # type: ignore[override]
        super().__setitem__(key, value)
        self._mark_modified()

    def __delitem__(self, key: str) -> None:  # type: ignore[override]
        super().__delitem__(key)
        self._mark_modified()

    def clear(self) -> None:  # type: ignore[override]
        super().clear()
        self._mark_modified()

    def pop(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        value = super().pop(key, default)
        self._mark_modified()
        return value

    def popitem(self) -> Any:  # type: ignore[override]
        item = super().popitem()
        self._mark_modified()
        return item

    def setdefault(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        if key not in self:
            self._mark_modified()
        return super().setdefault(key, default)

    def update(self, *args: Any, **kwargs: Any) -> None:  # type: ignore[override]
        if args or kwargs:
            self._mark_modified()
        super().update(*args, **kwargs)

    # -- persistence ----------------------------------------------------
    def save(self) -> None:
        """Persist the session immediately."""
        self.manager.save(self)


class FileSessionManager:
    """Manage loading and storing of file-based sessions."""

    def __init__(self, secret: str = "devsecret", directory: str = "/tmp/sess", cookie_name: str = "mini_session", nonce_bytes: int = 8) -> None:
        self.secret = secret.encode() if isinstance(secret, str) else secret
        self.directory = directory
        self.cookie_name = cookie_name
        self.nonce_bytes = nonce_bytes
        os.makedirs(self.directory, exist_ok=True)

    # -- public API -----------------------------------------------------
    def load_session(self, request: Request) -> FileSession:
        sid, created = self._get_or_create_sid(request)
        data = self._read(sid) or {}
        session = FileSession(self, sid, sid, data=data, new=not bool(data))
        session.cookie_needs_update = created
        return session

    def save(self, session: FileSession) -> None:
        if not session.modified:
            return
        path = self._session_path(session.sid)
        tmp_path = f"{path}.tmp-{secrets.token_hex(4)}"
        payload = {key: value for key, value in session.items()}
        with open(tmp_path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp_path, path)
        session.modified = False

    def get_cookie_value(self, session: FileSession) -> str:
        return session.nonce

    # -- internal helpers ----------------------------------------------
    def _get_or_create_sid(self, request: Request) -> tuple[str, bool]:
        raw = request.cookies.get(self.cookie_name)
        if raw:
            sid = self._normalize_sid(raw)
            if sid:
                return sid, False
        sid = secrets.token_hex(self.nonce_bytes)
        return sid, True

    def _normalize_sid(self, value: str) -> str | None:
        sid = value.strip()
        if not sid:
            return None
        if len(sid) > 256:
            sid = sid[:256]
        return sid

    def _read(self, sid: str) -> Optional[Dict[str, Any]]:
        path = self._session_path(sid)
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            return None
        except json.JSONDecodeError:
            return None

    def _session_path(self, sid: str) -> str:
        return os.path.join(self.directory, f"{sid}")

def save_session(session: FileSession) -> None:
    """Helper to manually flush session changes to disk."""
    session.save()
