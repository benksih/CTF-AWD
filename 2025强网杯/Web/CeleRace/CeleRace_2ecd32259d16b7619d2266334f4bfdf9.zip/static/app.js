async function api(path, options = {}) {
  const res = await fetch(path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || res.statusText);
  }
  return data;
}

function setStatus(text) {
  document.getElementById('status').textContent = text;
}

function setOutput(obj) {
  const pre = document.getElementById('output');
  pre.textContent = JSON.stringify(obj, null, 2);
}

async function refreshSession() {
  try {
    const data = await api('/session', { method: 'GET' });
    setStatus(`User: ${data.user} (role: ${data.role})`);
  } catch (err) {
    setStatus(`Failed to load session: ${err.message}`);
  }
}

document.getElementById('register-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const form = new FormData(ev.target);
  try {
    const data = await api('/register', {
      method: 'POST',
      body: JSON.stringify({
        username: form.get('username'),
        password: form.get('password'),
      }),
    });
    setOutput(data);
    await refreshSession();
  } catch (err) {
    setOutput({ error: err.message });
  }
});

document.getElementById('login-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const form = new FormData(ev.target);
  try {
    const data = await api('/login', {
      method: 'POST',
      body: JSON.stringify({
        username: form.get('username'),
        password: form.get('password'),
      }),
    });
    setOutput(data);
    await refreshSession();
  } catch (err) {
    setOutput({ error: err.message });
  }
});

document.getElementById('logout-btn').addEventListener('click', async () => {
  try {
    const data = await api('/logout', { method: 'POST', body: '{}' });
    setOutput(data);
  } catch (err) {
    setOutput({ error: err.message });
  } finally {
    await refreshSession();
  }
});

document.getElementById('echo-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const form = new FormData(ev.target);
  try {
    const data = await api('/tasks/echo', {
      method: 'POST',
      body: JSON.stringify({ message: form.get('message') || '' }),
    });
    setOutput(data);
  } catch (err) {
    setOutput({ error: err.message });
  }
});

document.getElementById('fetch-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const form = new FormData(ev.target);
  try {
    const payload = {
      url: form.get('url'),
    };
    const host = form.get('host');
    const body = form.get('body');
    if (host) payload.host = host;
    if (body) payload.body = body;
    const data = await api('/tasks/fetch', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setOutput(data);
  } catch (err) {
    setOutput({ error: err.message });
  }
});


document.getElementById('poll-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const form = new FormData(ev.target);
  try {
    const params = new URLSearchParams({ id: form.get('id') });
    const data = await api(`/tasks/result?${params.toString()}`);
    setOutput(data);
  } catch (err) {
    setOutput({ error: err.message });
  }
});

refreshSession();
