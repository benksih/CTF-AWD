#include <stdio.h>
#include <stdlib.h>

int main(void) {
    FILE *fp = fopen("/flag", "r");
    if (!fp) {
        perror("fopen");
        return 1;
    }
    char buf[256];
    if (!fgets(buf, sizeof(buf), fp)) {
        perror("fgets");
        fclose(fp);
        return 1;
    }
    fclose(fp);
    printf("%s", buf);
    return 0;
}
