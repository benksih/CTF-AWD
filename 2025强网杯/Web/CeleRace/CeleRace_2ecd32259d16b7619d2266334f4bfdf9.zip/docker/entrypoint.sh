#!/bin/sh
set -e

if [ -z "$SESSION_SECRET" ]; then
SESSION_SECRET=$(python - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
  )
  export SESSION_SECRET
fi

mkdir -p /var/lib/redis /var/run/redis /app/data
chown -R redis:redis /var/lib/redis
chown redis:redis /var/run/redis
chown -R web:app /app/data
chmod 0770 /app/data

if [ "$1" = "python" ] && [ "$2" = "-m" ] && [ "$3" = "src.app" ]; then
  exec "$@"
fi

if [ $# -eq 0 ]; then
  set -- supervisord -c /app/docker/supervisord.conf
fi

exec "$@"
