<?php

namespace App\Repositories;

class LangRepository extends BaseRepository
{
    private static array $langToLocale = [
        'Czech' => 'cs',
    ];
}
