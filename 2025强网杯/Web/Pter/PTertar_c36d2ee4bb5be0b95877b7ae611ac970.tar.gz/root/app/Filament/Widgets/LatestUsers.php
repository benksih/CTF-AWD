<?php

namespace App\Filament\Widgets;

use App\Models\User;
use Closure;
use Filament\Tables;
use Filament\Widgets\TableWidget as BaseWidget;
use Illuminate\Contracts\Support\Htmlable;
use Illuminate\Database\Eloquent\Builder;

class LatestUsers extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getTableHeading(): string | Htmlable | null
    {
        return __('dashboard.latest_user.page_title');
    }

    protected function isTablePaginationEnabled(): bool
    {
        return false;
    }

    protected function getTableQuery(): Builder
    {
        return User::query()->orderBy('id', 'desc')->limit(5);
    }

    protected function getTableColumns(): array
    {
        return [
            Tables\Columns\TextColumn::make('id')
                ->label(__('label.user.username'))
                ->formatStateUsing(fn ($state) => username_for_admin($state))
            ,
            Tables\Columns\TextColumn::make('email')->label(__('label.email')),
            Tables\Columns\BadgeColumn::make('status')->colors(['success' => 'confirmed', 'danger' => 'pending'])->label(__('label.status')),
            Tables\Columns\TextColumn::make('added')->dateTime()->label(__('label.added')),
        ];
    }
}
