<?php

namespace App\Filament\Resources\User\UserMedalResource\Pages;

use App\Filament\Resources\User\UserMedalResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserMedal extends CreateRecord
{
    protected static string $resource = UserMedalResource::class;
}
