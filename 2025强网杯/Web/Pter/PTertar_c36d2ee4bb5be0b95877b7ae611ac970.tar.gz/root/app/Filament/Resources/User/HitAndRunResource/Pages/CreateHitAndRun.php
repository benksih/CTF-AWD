<?php

namespace App\Filament\Resources\User\HitAndRunResource\Pages;

use App\Filament\Resources\User\HitAndRunResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHitAndRun extends CreateRecord
{
    protected static string $resource = HitAndRunResource::class;
}
