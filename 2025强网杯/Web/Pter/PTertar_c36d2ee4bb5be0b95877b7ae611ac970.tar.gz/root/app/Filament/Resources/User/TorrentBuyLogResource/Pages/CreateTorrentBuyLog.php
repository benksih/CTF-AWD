<?php

namespace App\Filament\Resources\User\TorrentBuyLogResource\Pages;

use App\Filament\Resources\User\TorrentBuyLogResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTorrentBuyLog extends CreateRecord
{
    protected static string $resource = TorrentBuyLogResource::class;
}
