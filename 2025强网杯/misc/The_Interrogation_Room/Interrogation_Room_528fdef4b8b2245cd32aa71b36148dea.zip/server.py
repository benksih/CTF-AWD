import os
import random
import string
from hashlib import sha256
import socketserver
import secrets

white_list = ['==','(',')','S0','S1','S2','S3','S4','S5','S6','S7','0','1','and','or']
TURNS = 25


def interrogate(expr, secrets):
	tokens = []
	i = 0
	while i < len(expr):
		if expr[i] in '()':
			tokens.append(expr[i])
			i += 1
		elif expr[i].isspace():
			i += 1
		elif expr[i] in '01':
			tokens.append(expr[i] == '1')
			i += 1
		else:
			start = i
			while i < len(expr) and (expr[i].isalnum() or expr[i] == '_' or expr[i] == '='):
				i += 1
			word = expr[start:i]
			
			if word in ['S0', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7']:
				idx = int(word[1])
				tokens.append(secrets[idx])
			elif word in ['True', 'true']:
				tokens.append(True)
			elif word in ['False', 'false']:
				tokens.append(False)
			elif word == 'and':
				tokens.append('and')
			elif word == 'or':
				tokens.append('or')
			elif word == 'not':
				tokens.append('not')
			elif word == '==':
				tokens.append('==')
			else:
				raise ValueError(f"Invalid token: {word}")
	
	def evaluate(tokens):
		precedence = {
			'==': 2,
			'not': 3,
			'and': 1,
			'or': 0
		}
		
		output = []
		ops = []
		
		for token in tokens:
			if token in [True, False]:
				output.append(token)
			elif token == '(':
				ops.append(token)
			elif token == ')':
				while ops and ops[-1] != '(':
					output.append(ops.pop())
				if ops and ops[-1] == '(':
					ops.pop()
				else:
					raise ValueError("Mismatched parentheses")
			elif token in ['==', 'not', 'and', 'or']:
				while (ops and ops[-1] != '(' and 
					   precedence.get(ops[-1], -1) >= precedence.get(token, -1)):
					output.append(ops.pop())
				ops.append(token)
		
		while ops:
			if ops[-1] == '(':
				raise ValueError("Mismatched parentheses")
			output.append(ops.pop())
		
		stack = []
		for token in output:
			if token in [True, False]:
				stack.append(token)
			elif token == 'not':
				if len(stack) < 1:
					raise ValueError("Invalid expression: not enough operands for 'not'")
				a = stack.pop()
				stack.append(not a)
			elif token == 'and':
				if len(stack) < 2:
					raise ValueError("Invalid expression: not enough operands for 'and'")
				b = stack.pop()
				a = stack.pop()
				stack.append(a and b)
			elif token == 'or':
				if len(stack) < 2:
					raise ValueError("Invalid expression: not enough operands for 'or'")
				b = stack.pop()
				a = stack.pop()
				stack.append(a or b)
			elif token == '==':
				if len(stack) < 2:
					raise ValueError("Invalid expression: not enough operands for '=='")
				b = stack.pop()
				a = stack.pop()
				stack.append(a == b)
		
		if len(stack) != 1:
			raise ValueError(f"Invalid expression: expected 1 result, got {len(stack)}")
		
		return stack[0]
	
	return evaluate(tokens)



class Task(socketserver.BaseRequestHandler):
	def proof_of_work(self):
		random.seed(os.urandom(8))
		proof = ''.join([random.choice(string.ascii_letters + string.digits) for _ in range(20)])
		_hexdigest = sha256(proof.encode()).hexdigest()
		self.send(f"sha256(XXXX+{proof[4:]}) == {_hexdigest}".encode())
		self.send(b'Give me XXXX: ')
		x = self.recv().encode()
		if len(x) != 4 or sha256(x + proof[4:].encode()).hexdigest() != _hexdigest:
			self.send('wrong')
			return False
		return True

	def recv(self):
		sz = 16384
		try:
			r = sz
			res = ""
			while r > 0:
				res += self.request.recv(r).decode()
				if res.endswith("\n"):
					r = 0
				else:
					r = sz - len(res)
			res = res.strip()
		except:
			res = ""
		return res.strip()

	def send(self, msg, newline=True):
		if isinstance(msg, bytes):
			msg += b'\n'
		else:
			msg += '\n'
			msg = msg.encode()
		self.request.sendall(msg)

	def interrogate_prisoner(self, ans, secrets, expr):
		try:
			S0, S1, S2, S3, S4, S5, S6, S7 = secrets
			r = interrogate(expr, secrets)
		except Exception as e:
			self.send("The prisoner pretends not to understand your question.\n", e)
			exit(0)
		return ans(r)

	def do_round(self):
		truth = lambda r: not not r
		lie = lambda r: not r
		secrets = []
		for i in range(8):
			secrets.append((True, False)[random.random() > 0.5])
		self.send("Welcome to the interrogation room! Detective, you are interrogating a cunning prisoner who holds 8 critical secrets.\nSome of these secrets are true intelligence while others are carefully planted disinformation.\nThe prisoner has agreed to answer your questions, but be warned - he will lie exactly twice during this session.\n")
		prisoner_deception = 2
		responses = [truth] * (17 - prisoner_deception) + [lie] * prisoner_deception
		random.shuffle(responses)
		for i in range(17):
			self.send("Ask your question:")
			question = self.recv()
			for word in question.split(" "):
				if word not in white_list:
					self.send("({}) The prisoner smirks: 'I refuse to answer that questionable phrasing!'".format(word))
					exit(0)
			res = str(self.interrogate_prisoner(responses[i], secrets, question))
			self.send("Prisoner's response: {}!\n".format(res))
		self.send("Now reveal the true secrets (1 for true, 0 for false):")
		return secrets == list(map(int, self.recv().split(" ")))

	def handle(self):
		if not self.proof_of_work():
			return 0
		self.send(
			"Notice: The prisoner is a trained operative and will lie exactly twice in the 17 answers he gives you! Can you still uncover the truth?")
		for i in range(TURNS):
			if i == 10:
				self.send(f'Here is a gift for you: {secrets.Gift()}')
			if not self.do_round():
				self.send("The prisoner laughs triumphantly. 'You fell for my deception! Now I walk free while you face disciplinary action.'\n")
				exit(0)
			else:
				self.send("The prisoner scowls as you expose his lies. 'Very well, ask your next round of questions then.'\n")
		self.send("The prisoner slumps in defeat: 'Alright, you win! I'll tell you everything.' He confesses all his secrets and reveals the hidden location of {}'\nAs he signs the confession, you notice a coded message hidden in his handwriting that leads you to the ultimate prize.".format(secrets.flag))

try:
	fork = socketserver.ForkingTCPServer
except:
	fork = socketserver.ThreadingTCPServer
class ForkingServer(fork, socketserver.TCPServer):
	pass

if __name__ == "__main__":
	HOST, PORT = '0.0.0.0', 9999
	server = ForkingServer((HOST, PORT), Task)
	server.allow_reuse_address = True
	server.serve_forever()