#!/bin/sh
set -e
while [ true ]; do
	socat -dd TCP4-LISTEN:70,fork,reuseaddr EXEC:'/home/ctf/chall',pty,echo=0,rawer,iexten=0
done

