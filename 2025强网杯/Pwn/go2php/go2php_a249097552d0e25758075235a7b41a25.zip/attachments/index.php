<?php
@error_reporting(E_ALL);

$upload_dir = '/home/ctf/'; // 目标目录

$file = $_FILES['file'];

if (!isset($file)) {
    die('upload error: No file uploaded.');
}

// 获取上传的文件名
// $filename = basename($file['name']); // 不要使用原始文件名
$file_ext = pathinfo($file['name'], PATHINFO_EXTENSION); // 获取文件扩展名

// 生成随机文件名
$new_filename = bin2hex(random_bytes(16)); // 生成 32 字符的十六进制随机字符串

if ($file_ext) {
    $new_filename .= '.' . $file_ext; // 添加扩展名
}

// 构建完整的目标路径
$target_path = $upload_dir . $new_filename;

// 移动上传的文件
if (move_uploaded_file($file['tmp_name'], $target_path)) {
    echo "upload success: File uploaded to " . htmlspecialchars($target_path);
} else {
    echo 'upload error: Failed to move uploaded file.';
}

?>