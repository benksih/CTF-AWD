#!/bin/bash
service apache2 start &
# 目标目录
TARGET_DIR="/home/ctf"

# 上次修改时间 (初始值)
LAST_MODIFIED=$(find "$TARGET_DIR" -type f -print0 | xargs -0 stat -c '%Y' | sort -nr | head -n 1)

# 循环监控
while true
do
  # 获取当前最新修改时间
  CURRENT_MODIFIED=$(find "$TARGET_DIR" -type f -print0 | xargs -0 stat -c '%Y' | sort -nr | head -n 1)

  # 检查是否有新的修改
  if [ "$CURRENT_MODIFIED" -gt "$LAST_MODIFIED" ]; then
    echo "检测到新文件!"

    # 获取所有文件列表并按修改时间排序
    NEW_FILES=$(find "$TARGET_DIR" -type f -print0 | xargs -0 stat -c '%n %Y' | sort -k2,2 -nr | awk '{$1=$1;print $1}' | head -n 1)

    # 获取新文件路径（假设只有一个新文件）
    NEW_FILE_PATH=$(echo "$NEW_FILES")

    echo "新文件路径: $NEW_FILE_PATH"

    # 检查是否是php文件
    if [[ "$NEW_FILE_PATH" == *.php ]]; then
      echo "执行 PHP 文件: $NEW_FILE_PATH"
      php "$NEW_FILE_PATH"
    else
      echo "不是 PHP 文件，跳过执行."
    fi

    # 更新上次修改时间
    LAST_MODIFIED="$CURRENT_MODIFIED"
  fi

  # 休眠一段时间
  sleep 1
done