#!/bin/sh

service apache2 start &

sleep 3

# 尝试以 ctf 用户启动 monitor.sh（如果存在）
MONITOR="/home/ctf/monitor.sh"
CTF_USER="ctf"
LOG="/var/log/monitor.log"
if [ -f "${MONITOR}" ]; then
    mkdir -p "$(dirname "${LOG}")"
    touch "${LOG}" 2>/dev/null || true
    chown "${CTF_USER}:${CTF_USER}" "${LOG}" 2>/dev/null || true
    chown "${CTF_USER}:${CTF_USER}" "${MONITOR}" 2>/dev/null || true
    chmod u+x "${MONITOR}" 2>/dev/null || true

    echo "[start.sh] starting ${MONITOR} as ${CTF_USER}"
    if command -v su >/dev/null 2>&1; then
        su -s /bin/bash "${CTF_USER}" -c "${MONITOR} >> ${LOG} 2>&1 &" || true
    elif command -v sudo >/dev/null 2>&1; then
        sudo -u "${CTF_USER}" bash -c "${MONITOR} >> ${LOG} 2>&1 &" || true
    elif command -v runuser >/dev/null 2>&1; then
        runuser -u "${CTF_USER}" -- bash -c "${MONITOR} >> ${LOG} 2>&1 &" || true
    fi
else
    echo "[start.sh] monitor not found: ${MONITOR}"
fi

# remove start script if you want it one-shot
rm -f /start.sh 2>/dev/null || true

# keep container alive (or exit if you prefer)
sleep infinity