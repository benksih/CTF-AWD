CKEDITOR.plugins.setLang( 'kwords', 'zh-cn', {
	btnLabel: 'Keyword'
} );