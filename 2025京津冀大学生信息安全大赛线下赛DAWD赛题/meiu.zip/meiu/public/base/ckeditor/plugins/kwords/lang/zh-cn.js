
CKEDITOR.plugins.setLang( 'kwords', 'zh-cn', {
	btnLabel: '关键词'
} );
