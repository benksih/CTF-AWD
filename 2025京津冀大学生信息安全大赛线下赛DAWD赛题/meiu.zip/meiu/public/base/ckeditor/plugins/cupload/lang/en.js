CKEDITOR.plugins.setLang( 'cupload', 'zh-cn', {
	btnLabel: 'Multi Upload'
} );