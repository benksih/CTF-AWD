
CKEDITOR.plugins.setLang( 'cupload', 'zh-cn', {
	btnLabel: '批量上传'
} );
