<?php
/**
 * CMS基本数据调用
 * 可以在模版中调用
 * 依赖于cms模块
 */

defined('IN_MWEB') || exit('Access denied!');

class cms extends x_cms_helper{
}