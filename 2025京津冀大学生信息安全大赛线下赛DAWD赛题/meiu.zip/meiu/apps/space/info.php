<?php
defined('IN_MWEB') or die('access denied');

return array(
    'name'      => '个人空间',
    'version'   => '1.0',
    'desc'      => '用户个人中心/个人主页',
    'author'    => 'Lingter',
    'author_url'=> 'http://www.test.cn',
    'issystem'  => 1,
    'ismy'      => 0,
    'isspace'   => 0
);