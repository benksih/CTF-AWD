<?php 
defined('IN_MWEB') or die('access denied');
defined('IN_MY') or die('access denied');

echo 'comment dashboard!';