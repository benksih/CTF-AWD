<?php 
defined('IN_MWEB') or die('access denied');

checkLogin();

$path = getGet('path');

//读取原图下载
$storage = storage::instance();
$storage->download(base64_decode($path));