<?php
defined('IN_MWEB') or die('access denied');

return array(
    'name'      => '相册',
    'version'   => '1.0',
    'desc'      => '相册',
    'author'    => 'Lingter',
    'author_url'=> 'http://www.test.cn',
    'issystem'  => 1,
    'ismy'      => 1,
    'isspace'   => 1
);