<?php
defined('IN_MWEB') or die('access denied');

return array(
    'name'      => '短信服务',
    'version'   => '1.0',
    'desc'      => '发送短信相关服务',
    'author'    => 'Lingter',
    'author_url'=> 'http://www.test.cn',
    'issystem'  => 0,
    'ismy'      => 0,
    'isspace'   => 0
);