<?php
defined('IN_MWEB') or die('access denied');

$view->display('index.php');