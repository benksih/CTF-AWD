<div class="main-head">
    <h3>插件设置</h3>
    <a href="<?php echo U('base','setting','a=plugin');?>" >&lt;&lt;返回</a>
</div>
<?php echo $pluginSettingContent;?>