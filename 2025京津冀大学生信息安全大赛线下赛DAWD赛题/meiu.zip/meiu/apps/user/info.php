<?php
defined('IN_MWEB') or die('access denied');

return array(
    'name'      => '用户',
    'version'   => '1.0',
    'desc'      => '用户系统',
    'author'    => 'Lingter',
    'author_url'=> 'http://www.test.cn',
    'issystem'  => 1,
    'ismy'      => 0,
    'isspace'   => 0
);