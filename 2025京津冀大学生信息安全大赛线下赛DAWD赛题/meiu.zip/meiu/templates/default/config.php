<?php return array (
  'name' => '默认模板',
  'author' => 'Meiu Studio',
  'dirname' => 'default',
  'homepage' => 'http://www.test.cn/',
  'version' => '1.0',
  'disable' => 0,
  'file_explan' => 
  array (
    'default' => 
    array (
      'album' => '',
      'common' => '文件头尾等',
      'css' => 'CSS样式',
      'default.php' => '首页页面',
      'images' => '图片',
      'my' => '用户中心',
      'preview.jpg' => '缩略图',
      'user' => '用户相关',
    ),
    'default/user' => 
    array (
      'login.php' => '登录页',
      'login_foot.php' => '登录和注册统一页脚',
      'register.php' => '注册页',
    ),
  ),
);