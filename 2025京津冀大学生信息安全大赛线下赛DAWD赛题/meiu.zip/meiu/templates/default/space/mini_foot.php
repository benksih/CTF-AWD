<?php echo getSetting('stats'); ?>
</body>
</html>