<div class="footer-wrap">
    <div class="inner copyright">
    Copyright © 2010-2025 Powered By <a href="http://www.test.cn" target="_blank"><?php echo SOFT_NAME.' '.SOFT_VERSION; ?></a>
    <br>
    <?php echo getSetting('icp'); ?> Processed in <?php echo G('begin','end',4); ?>s, <?php echo N('db'); ?> query.
    </div>
</div>
<?php echo getSetting('stats'); ?>
</body>
</html>