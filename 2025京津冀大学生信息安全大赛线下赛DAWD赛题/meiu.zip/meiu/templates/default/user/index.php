<?php $this->display('common/head.php'); ?>
<div class="container">
    <nav class="secondary-nav">
    <ul class="nav-list">
        <li <?php if($_G['uri']['m']=='index' && !getGet('t')): ?>class="active"<?php endif; ?> data-index="0">
            <a target="_self" href="<?php echo U('user','index')?>">热门摄影师</a>
        </li>
        <li <?php if($_G['uri']['m']=='index' && getGet('t')=='new'): ?>class="active"<?php endif; ?> data-index="1">
            <a target="_self" href="<?php echo U('user','index','t=new')?>">潜力新人</a>
        </li>
    </ul>
</nav>
    <div class="list-body">
        <div class="page-content" id="userlist">
            <div class="listCont">
                <?php $this->display('user/user_list.php'); ?>
            </div>
            <div class="pageset" style="display:none"><?php echo $pagestr; ?></div> 
        </div>
    </div>
    <div class="loadingbar" style="display:none;"><label>努力加载中</label></div>
</div>
<script>
$('#userlist').delegate('.follow-button a','click',function(){
    var that = this;
    if(this.href=='javascript:void(0)'){
        return false;
    }
    var param = {};
    if($(this).hasClass('followed')){
        param.a = 'cancel';
    }
    return opt_one(this,false,param,function(){
        if($(that).hasClass('follow')){
            $(that).removeClass('follow').addClass('followed').html('取消关注');
        }else{
            $(that).removeClass('followed').addClass('follow').html('关注');
        }
    });
});
</script>
<script type="text/javascript" src="<?php echo S('album','js/loadmore.js'); ?>"></script>
<?php $this->display('common/foot.php'); ?>