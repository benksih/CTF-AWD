<div id="footer">
    <div class="inner copyright">
    Copyright © 2010-2025 Meiu.
    <br>
    <?php echo getSetting('icp'); ?> Processed in <?php echo G('begin','end',4); ?>s, <?php echo N('db'); ?> query.
    </div>
</div>
<?php echo getSetting('stats'); ?>
</body>
</html>