<?php $this->display('common/head.php');?>
<div class="wrap">
sfsdf
</div>
<?php $this->display('common/foot.php'); ?>