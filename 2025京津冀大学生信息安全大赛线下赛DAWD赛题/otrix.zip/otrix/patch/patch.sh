#!/bin/bash

# 停止服务
pkill -f "gunicorn.*app:app" 2>/dev/null || true
pkill -f "python.*app.py" 2>/dev/null || true

# 复制修复文件
cp "$(dirname "$0")/app_secure.py" /home/ctf/app.py
cp "$(dirname "$0")/Archives_safe.py" /home/ctf/Archives.py

# 设置权限
chown service:service /home/ctf/app.py 2>/dev/null || true
chown service:service /home/ctf/Archives.py 2>/dev/null || true
chmod 644 /home/ctf/app.py 2>/dev/null || true
chmod 644 /home/ctf/Archives.py 2>/dev/null || true

# 重启服务
cd /home/ctf
gunicorn -w 1 -b 0.0.0.0:5000 app:app --user service --group service --reload --daemon 2>/dev/null || {
    nohup python3 app.py > /dev/null 2>&1 &
}