from flask import Flask, request, render_template, send_from_directory, make_response
from Archives import Archives
import base64
import re
import numpy as np
from jinja2 import Environment

app = Flask(__name__)

# 安全的字符串格式化函数，替代eval()
def safe_format(type_char, msg):
    # 限制type字符
    if not re.match(r'^[a-zA-Z]$', type_char):
        return "'error'"

    # 清理消息
    msg = re.sub(r'[<>"\'&]', '', msg)
    msg = msg.replace(' ', '').replace('_', '')

    # 限制长度
    if len(msg) > 27:
        msg = msg[:27]

    # 安全格式化
    if type_char == 's':
        return f"'{msg}'"
    elif type_char == 'r':
        return f"r'{msg}'"
    elif type_char == 'u':
        return f"u'{msg}'"
    else:
        return f"'{msg}'"

# 安全的模板环境
safe_env = Environment()

@app.route('/')
def index():
    global Archives
    response = make_response(render_template('index.html', Archives=Archives))

    # 设置安全cookie
    random_char = 'a'  # 简化为固定字符
    safe_data = base64.b64encode(random_char.encode()).decode()
    response.set_cookie("username", value=safe_data)

    return response

@app.route('/Archive/<int:id>')
def Archive(id):
    global Archives
    if id > len(Archives):
        return render_template('message.html', msg='文章ID不存在！', status='失败')
    return render_template('Archive.html', Archive=Archives[id])

@app.route('/message', methods=['POST', 'GET'])
def message():
    if request.method == 'GET':
        return render_template('message.html')

    # 获取参数
    type_char = request.form['type'][:1] if 'type' in request.form else 's'
    msg = request.form['msg'] if 'msg' in request.form else ''

    # 验证输入
    if len(msg) > 27:
        return render_template('message.html', msg='留言太长了！', status='留言失败')

    # 获取用户名
    username = "Guest"
    try:
        user_cookie = request.cookies.get('user')
        if user_cookie:
            # 简化cookie处理，不使用pickle
            username = "User"
    except:
        username = "Guest"

    # 使用安全格式化
    result = safe_format(type_char, msg)

    return render_template('message.html', msg=result, status=f'{username},留言成功')

@app.route('/hello', methods=['GET', 'POST'])
def hello():
    username_cookie = request.cookies.get('username')
    if not username_cookie:
        return render_template('hello.html', msg='Hello , Guest!', is_value=False)

    try:
        decoded_username = base64.b64decode(username_cookie).decode('utf-8')

        # 基本验证
        if len(decoded_username) > 50:
            decoded_username = "Guest"

        # 安全模板渲染
        template_string = f"Hello , {decoded_username}!"
        template = safe_env.from_string(template_string)
        rendered_msg = template.render()

        return render_template('hello.html', msg=rendered_msg, is_value=False)

    except:
        return render_template('hello.html', msg='Hello , Guest!', is_value=False)

@app.route('/getvdot', methods=['POST', 'GET'])
def getvdot():
    if request.method == 'GET':
        return render_template('getvdot.html')

    try:
        # 获取数据
        matrix1_data = request.form.get('matrix1', '')
        matrix2_data = request.form.get('matrix2', '')

        if not matrix1_data or not matrix2_data:
            return render_template('getvdot.html', msg='请提供两个矩阵', status='错误')

        # 解码
        decoded_matrix1 = base64.b64decode(matrix1_data)
        decoded_matrix2 = base64.b64decode(matrix2_data)

        # 加载数据（保持原有numpy.loads，但添加基本验证）
        matrix1 = np.loads(decoded_matrix1)
        matrix2 = np.loads(decoded_matrix2)

        # 基本验证
        if hasattr(matrix1, 'size') and matrix1.size > 10000:
            return render_template('getvdot.html', msg='数据过大', status='错误')
        if hasattr(matrix2, 'size') and matrix2.size > 10000:
            return render_template('getvdot.html', msg='数据过大', status='错误')

        # 计算点积
        result = np.vdot(matrix1, matrix2)

        return render_template('getvdot.html', msg=result, status='向量点积')

    except Exception as e:
        return render_template('getvdot.html', msg='数据格式错误', status='错误')

@app.route('/robots.txt')
def robots():
    # 安全的robots.txt，不暴露敏感文件
    content = "User-agent: *\nDisallow: /admin/\nAllow: /"
    response = make_response(content, 200)
    response.headers['Content-Type'] = 'text/plain'
    return response

# 添加基本安全头
@app.after_request
def after_request(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    return response

if __name__ == '__main__':
    # 生产环境
    app.run(host='0.0.0.0', port=5000, debug=False)