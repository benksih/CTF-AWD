from flask import Flask, request, render_template,send_from_directory, make_response
from Archives import Archives
import pickle,base64,os
from jinja2 import Environment
from random import choice
import numpy
import builtins
import io
import re
app = Flask(__name__)
ARZFebXfDVyDqNwBapzZWoofbithirtb = Environment()
def guGVWcwBLYmQVAKWiPeXqRRSVWKauaKx(type,str):
    ToWBKAxHhFMDaTnnvWdwZCKbQXmXAdml = "%s'%s'"%(type,str)
    print(ToWBKAxHhFMDaTnnvWdwZCKbQXmXAdml)
    return eval(ToWBKAxHhFMDaTnnvWdwZCKbQXmXAdml)
def zZlhXLaAnnRSoAFNghykPyvDQNjbXFMd():
    kzgncHrehswmBOcEBSUyELqpjFLLmxbb = ['class','+','getitem','request','args','subclasses','builtins','{','}']
    return choice(kzgncHrehswmBOcEBSUyELqpjFLLmxbb)
@app.route('/')
def index():
    global Archives
    fiWXDJGYxnBpzFNXFjxUAKhUWWuKnvTj = make_response(render_template('index.html', Archives = Archives))
    WGhQTmjKHEHiSEqSbRLXYtHWuypEvFet = bytes(zZlhXLaAnnRSoAFNghykPyvDQNjbXFMd(), encoding = "utf-8")
    gxVrZFEiuunWEhQPKEaUWHInnvuiBKAs = base64.b64encode(WGhQTmjKHEHiSEqSbRLXYtHWuypEvFet)
    fiWXDJGYxnBpzFNXFjxUAKhUWWuKnvTj.set_cookie("username", value=gxVrZFEiuunWEhQPKEaUWHInnvuiBKAs)
    return fiWXDJGYxnBpzFNXFjxUAKhUWWuKnvTj
@app.route('/Archive/<int:id>')
def Archive(id):
    global Archives
    if id>len(Archives):
        return render_template('message.html', msg='文章ID不存在！', status='失败')
    return render_template('Archive.html',Archive = Archives[id])
@app.route('/message',methods=['POST','GET'])
def UDJsnQztuGFctiAVXXrsDwmHhayfpqNE():
    if request.method == 'GET':
        return render_template('message.html')
    else:
        type = request.form['type'][:1]
        mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx = request.form['msg']
        try:
            JwYHEEZfnFOdAWPoaJnMvrwClBmbNOac = base64.b64decode(request.cookies.get('user'))
            JwYHEEZfnFOdAWPoaJnMvrwClBmbNOac = pickle.loads(JwYHEEZfnFOdAWPoaJnMvrwClBmbNOac)
            rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt = JwYHEEZfnFOdAWPoaJnMvrwClBmbNOac["name"]
        except Exception as SDNLbcUSIHAgJePfSKSpcwwfmVWASogu:
            print(SDNLbcUSIHAgJePfSKSpcwwfmVWASogu)
            rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt = "Guest"
        if len(mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx)>27:
            return render_template('message.html', msg='留言太长了！', status='留言失败')
        mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx = mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx.replace(' ','')
        mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx = mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx.replace('_', '')
        ToWBKAxHhFMDaTnnvWdwZCKbQXmXAdml = guGVWcwBLYmQVAKWiPeXqRRSVWKauaKx(type,mVPDCPAgfwfQGDlYnrIoUYElnyBIWSRx)
        return render_template('message.html',msg=ToWBKAxHhFMDaTnnvWdwZCKbQXmXAdml,status='%s,留言成功'%rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt)
@app.route('/hello',methods=['GET', 'POST'])
def hBMvkUIbAAFniGefBAeqvEXMdfQrGEKs():
    rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt = request.cookies.get('username')
    rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt = str(base64.b64decode(rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt), encoding = "utf-8")
    HHdqsAbpnCrzeTcyvUveivchEGDuNyLu = ARZFebXfDVyDqNwBapzZWoofbithirtb.from_string("Hello , " + rIOaNfPnDAjFbnWPbPtwpwsvbaJRFSxt + '!').render()
    LUwoBWkioaYCbIhqyXHQJecdQjDJFYst = False
    return render_template('hello.html', msg=HHdqsAbpnCrzeTcyvUveivchEGDuNyLu,is_value=LUwoBWkioaYCbIhqyXHQJecdQjDJFYst)
@app.route('/getvdot',methods=['POST','GET'])
def MtpMfhlYxNiFOzPoLlfQysrfiTBfUuuh():
    if request.method == 'GET':
        return render_template('getvdot.html')
    else:
        PUjKqJlpsmTTwfzjObmWCVLYTqEGqDMA = base64.b64decode(request.form['matrix1'])
        vIoaaSyRzhzchgDnSGesoWrOHTsnOqYq = base64.b64decode(request.form['matrix2'])
        try:
            PUjKqJlpsmTTwfzjObmWCVLYTqEGqDMA = numpy.loads(PUjKqJlpsmTTwfzjObmWCVLYTqEGqDMA)
            vIoaaSyRzhzchgDnSGesoWrOHTsnOqYq = numpy.loads(vIoaaSyRzhzchgDnSGesoWrOHTsnOqYq)
        except Exception as SDNLbcUSIHAgJePfSKSpcwwfmVWASogu:
            print(SDNLbcUSIHAgJePfSKSpcwwfmVWASogu)
        HZDZpDiVvnfwyqFVVjOgVmbMElHGTmRL = numpy.vdot(PUjKqJlpsmTTwfzjObmWCVLYTqEGqDMA,vIoaaSyRzhzchgDnSGesoWrOHTsnOqYq)
        print(HZDZpDiVvnfwyqFVVjOgVmbMElHGTmRL)
        return render_template('getvdot.html',msg=HZDZpDiVvnfwyqFVVjOgVmbMElHGTmRL,status='向量点积')
@app.route('/robots.txt',methods=['GET'])
def CBbULztnkgpDCZkZWzBtUlacdjBvUxYt():
    return send_from_directory('/', 'flag', as_attachment=True)
if __name__ == '__main__':
    app.run(host='0.0.0.0',port='5000',debug=True)
